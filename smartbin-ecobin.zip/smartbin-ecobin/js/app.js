/* ============================================
   SMARTBIN & ECOBIN — Global JavaScript
   Interactions, Animations, Utilities
   ============================================ */

// ── Toast Notification ──
function showToast(title, message, type = 'success') {
  const existing = document.querySelector('.eco-toast');
  if (existing) existing.remove();

  const iconMap = {
    success: 'fa-check',
    error: 'fa-xmark',
    warning: 'fa-exclamation',
    info: 'fa-info'
  };

  const toast = document.createElement('div');
  toast.className = 'eco-toast';
  toast.style.borderLeftColor = type === 'success' ? 'var(--success)' :
    type === 'error' ? 'var(--danger)' :
    type === 'warning' ? 'var(--warning)' : 'var(--info)';
  toast.innerHTML = `
    <div class="toast-icon" style="background: var(--primary-light); color: var(--primary);">
      <i class="fa-solid ${iconMap[type]}"></i>
    </div>
    <div class="toast-body">
      <strong>${title}</strong>
      <small>${message}</small>
    </div>
    <button class="toast-close" onclick="this.parentElement.classList.remove('show'); setTimeout(() => this.parentElement.remove(), 400);">
      <i class="fa-solid fa-xmark"></i>
    </button>
  `;
  document.body.appendChild(toast);
  requestAnimationFrame(() => {
    requestAnimationFrame(() => toast.classList.add('show'));
  });
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 5000);
}

// ── Counter Animation ──
function animateCounter(element, target, duration = 1500, prefix = '', suffix = '') {
  const start = 0;
  const startTime = performance.now();

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
    const current = Math.floor(start + (target - start) * eased);
    element.textContent = prefix + current.toLocaleString('id-ID') + suffix;
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}

// ── Initialize All Counters ──
function initCounters() {
  const counters = document.querySelectorAll('[data-counter]');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.counter);
        const prefix = el.dataset.prefix || '';
        const suffix = el.dataset.suffix || '';
        animateCounter(el, target, 1500, prefix, suffix);
        observer.unobserve(el);
      }
    });
  }, { threshold: 0.5 });
  counters.forEach(c => observer.observe(c));
}

// ── Ripple Effect ──
function addRipple(e) {
  const btn = e.currentTarget;
  const circle = document.createElement('span');
  const diameter = Math.max(btn.clientWidth, btn.clientHeight);
  const radius = diameter / 2;
  const rect = btn.getBoundingClientRect();
  circle.style.width = circle.style.height = `${diameter}px`;
  circle.style.left = `${e.clientX - rect.left - radius}px`;
  circle.style.top = `${e.clientY - rect.top - radius}px`;
  circle.classList.add('ripple');
  const existing = btn.querySelector('.ripple');
  if (existing) existing.remove();
  btn.appendChild(circle);
  setTimeout(() => circle.remove(), 600);
}

function initRipple() {
  document.querySelectorAll('.ripple-effect, .btn-eco').forEach(btn => {
    btn.addEventListener('click', addRipple);
  });
}

// ── Confetti ──
function launchConfetti(duration = 3000) {
  const container = document.createElement('div');
  container.className = 'confetti-container';
  document.body.appendChild(container);

  const colors = ['#10B981', '#6EE7B7', '#14B8A6', '#F59E0B', '#3B82F6', '#EF4444', '#8B5CF6'];
  const shapes = ['square', 'circle'];

  for (let i = 0; i < 60; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti-piece';
    piece.style.left = Math.random() * 100 + '%';
    piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDelay = Math.random() * 2 + 's';
    piece.style.animationDuration = (2 + Math.random() * 2) + 's';
    if (shapes[Math.floor(Math.random() * 2)] === 'circle') {
      piece.style.borderRadius = '50%';
    } else {
      piece.style.transform = `rotate(${Math.random() * 360}deg)`;
    }
    container.appendChild(piece);
  }

  setTimeout(() => container.remove(), duration + 2000);
}

// ── Stepper Animation (Proses Setor) ──
function runStepper(stepperSelector, stepDelay = 2500) {
  const items = document.querySelectorAll(`${stepperSelector} .stepper-item`);
  let current = 0;

  function activateStep(index) {
    if (index >= items.length) {
      // All done - launch confetti on last step
      launchConfetti();
      return;
    }
    items[index].classList.remove('pending');
    items[index].classList.add('active');

    // Update circle to spinner
    const circle = items[index].querySelector('.stepper-circle');
    circle.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

    setTimeout(() => {
      items[index].classList.remove('active');
      items[index].classList.add('completed');
      circle.innerHTML = '<i class="fa-solid fa-check"></i>';

      // Show result if exists
      const result = items[index].querySelector('.stepper-result');
      if (result) {
        result.style.display = 'block';
        result.classList.add('animate-fadeInUp');
      }

      current++;
      setTimeout(() => activateStep(current), 500);
    }, stepDelay);
  }

  // Mark all as pending initially
  items.forEach(item => item.classList.add('pending'));
  activateStep(0);
}

// ── QR Code Timer ──
function startQRTimer(displaySelector, totalSeconds = 300) {
  const display = document.querySelector(displaySelector);
  if (!display) return;

  let remaining = totalSeconds;

  function update() {
    const min = Math.floor(remaining / 60).toString().padStart(2, '0');
    const sec = (remaining % 60).toString().padStart(2, '0');
    display.textContent = `${min}:${sec}`;

    if (remaining <= 0) {
      display.textContent = '00:00';
      display.style.color = 'var(--danger)';
      return;
    }
    remaining--;
    setTimeout(update, 1000);
  }
  update();
}

// ── OTP Auto Focus ──
function initOTPInputs() {
  const inputs = document.querySelectorAll('.otp-inputs input');
  inputs.forEach((input, index) => {
    input.addEventListener('input', (e) => {
      if (e.target.value.length === 1 && index < inputs.length - 1) {
        inputs[index + 1].focus();
      }
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !e.target.value && index > 0) {
        inputs[index - 1].focus();
      }
    });
    // Only allow numbers
    input.addEventListener('input', (e) => {
      e.target.value = e.target.value.replace(/[^0-9]/g, '');
    });
  });
}

// ── Toggle Password Visibility ──
function initPasswordToggles() {
  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = btn.parentElement.querySelector('input');
      const icon = btn.querySelector('i');
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
      } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
      }
    });
  });
}

// ── Toggle Saldo Visibility ──
function initSaldoToggle() {
  const toggleBtn = document.querySelector('.saldo-toggle');
  const saldoAmount = document.querySelector('.saldo-amount');
  if (!toggleBtn || !saldoAmount) return;

  let hidden = false;
  const originalText = saldoAmount.textContent;

  toggleBtn.addEventListener('click', () => {
    hidden = !hidden;
    const icon = toggleBtn.querySelector('i');
    if (hidden) {
      saldoAmount.textContent = 'Rp •••••••';
      icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
      saldoAmount.textContent = originalText;
      icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
  });
}

// ── Sidebar Toggle (Admin) ──
function initSidebarToggle() {
  const toggle = document.querySelector('.toggle-sidebar');
  const sidebar = document.querySelector('.admin-sidebar');
  if (!toggle || !sidebar) return;

  toggle.addEventListener('click', () => {
    sidebar.classList.toggle('collapsed');
    sidebar.classList.toggle('mobile-open');
  });
}

// ── Eco Tabs ──
function initEcoTabs() {
  document.querySelectorAll('.eco-tabs').forEach(tabGroup => {
    const tabs = tabGroup.querySelectorAll('.eco-tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        // Show corresponding content
        const target = tab.dataset.tab;
        if (target) {
          document.querySelectorAll('.tab-content-panel').forEach(panel => {
            panel.style.display = 'none';
          });
          const targetPanel = document.getElementById(target);
          if (targetPanel) {
            targetPanel.style.display = 'block';
            targetPanel.classList.add('animate-fadeIn');
          }
        }
      });
    });
  });
}

// ── Eco Chips (Filter) ──
function initEcoChips() {
  document.querySelectorAll('.chip-group').forEach(group => {
    const chips = group.querySelectorAll('.eco-chip');
    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        if (!group.dataset.multi) {
          chips.forEach(c => c.classList.remove('active'));
        }
        chip.classList.toggle('active');
      });
    });
  });
}

// ── Animate Elements on Scroll ──
function initScrollAnimations() {
  const elements = document.querySelectorAll('.animate-on-scroll');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-fadeInUp');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  elements.forEach(el => observer.observe(el));
}

// ── Progress Bar Animation ──
function initProgressBars() {
  const bars = document.querySelectorAll('.eco-progress .progress-fill');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const target = entry.target.dataset.width;
        entry.target.style.width = target + '%';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });
  bars.forEach(bar => {
    bar.style.width = '0%';
    observer.observe(bar);
  });
}

// ── Skeleton Loading ──
function showSkeleton(container, count = 3) {
  let html = '';
  for (let i = 0; i < count; i++) {
    html += `
      <div style="padding: 16px; margin-bottom: 12px;">
        <div class="d-flex align-items-center gap-3">
          <div class="skeleton skeleton-circle"></div>
          <div style="flex:1">
            <div class="skeleton skeleton-title"></div>
            <div class="skeleton skeleton-text"></div>
          </div>
        </div>
      </div>`;
  }
  container.innerHTML = html;
}

function hideSkeleton(container, realContent) {
  setTimeout(() => {
    container.innerHTML = realContent;
    container.classList.add('animate-fadeIn');
  }, 1200);
}

// ── Format Numbers (Indonesian) ──
function formatRupiah(num) {
  return 'Rp ' + num.toLocaleString('id-ID');
}

function formatPoin(num) {
  return num.toLocaleString('id-ID') + ' Poin';
}

// ── Initialize All ──
document.addEventListener('DOMContentLoaded', () => {
  initCounters();
  initRipple();
  initPasswordToggles();
  initSaldoToggle();
  initSidebarToggle();
  initEcoTabs();
  initEcoChips();
  initScrollAnimations();
  initProgressBars();
  initOTPInputs();

  // Demo toast after 2 seconds on dashboard
  if (document.querySelector('.glass-card')) {
    setTimeout(() => {
      showToast('🎉 Reward Masuk!', '+500 Poin berhasil ditambahkan ke saldo Anda', 'success');
    }, 2000);
  }
});
